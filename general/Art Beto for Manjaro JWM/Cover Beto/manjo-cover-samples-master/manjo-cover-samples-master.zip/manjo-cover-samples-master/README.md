# manjaro-cover-guide-samples
Manjaro user guide cover graphics.
![alt text](manjaro-guide-preview.png "Preview Image")
